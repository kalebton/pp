<h1>Python Mass Sender</h1>
<p><a href="https://github.com/MisterSpyx/Python-Sender-/"></a>
<a href="https://github.com/MisterSpyx/Python-Sender-/r"><img src="https://img.shields.io/badge/Release-Stable-orange.svg" alt="Stage" data-canonical-src="https://img.shields.io/badge/Release-Stable-orange.svg" style="max-width:100%;"></a>
<a href="https://github.com/MisterSpyx/Python-Sender-/"><img src="https://img.shields.io/badge/Supported%20OS-Linux%2FWindows-brightgreengreen.svg" alt="Build" data-canonical-src="https://img.shields.io/badge/Supported%20OS-Linux%2FWindows-brightgreengreen.svg" style="max-width:100%;"></a></p>
<p> Smpt Mass Random Sender Tool 🔓  </p>

<h2>Smtp Sender</h2>

<img src="https://i.imgur.com/4zwfniZ.png" data-canonical-src="https://i.imgur.com/4zwfniZ.png" style="max-width:100%;">
<img src="https://i.imgur.com/JqyAirM.png" data-canonical-src="https://i.imgur.com/JqyAirM.png" style="max-width:100%;">

<h2>Mass Advanced Python Smtp Sender </h2>
<h2>Usage</h2>
<h3>Smtp Format : server.com|25|user|pass</h3>
<h1>put ur maillist in the same path of mass.py</h1>
<table>
<thead>
<tr>
<th>Smtps</th>
<th>Letter</th>
<th>Informations</th>
</tr>
</thead>
<tbody>
<tr>
<td>/Send3r</td>
<td>/Send3r</td>
<td>/Send3r</td>
</tr>
</tbody></table>

## Installation [Linux](https://wikipedia.org/wiki/Linux) [![alt tag](http://icons.iconarchive.com/icons/dakirby309/simply-styled/32/OS-Linux-icon.png)](https://fr.wikipedia.org/wiki/Linux)

```bash
git clone https://github.com/MisterSpyx/Python-Sender.git
cd Python-Sender-
python mass.py
```

## Installation [Android](https://wikipedia.org/wiki/Android) [![alt tag](https://cdn1.iconfinder.com/data/icons/logotypes/32/android-32.png)](https://fr.wikipedia.org/wiki/Android)

Download [Termux](https://play.google.com/store/apps/details?id=com.termux)

```bash
pip2 install python2
pip2 install colorama
pkg install git
git clone https://github.com/MisterSpyx/Python-Sender.git
cd Python-Sender/
python2 mass.py
```

## Installation [Windows ](https://wikipedia.org/wiki/Microsoft_Windows)[![alt tag](http://icons.iconarchive.com/icons/tatice/cristal-intense/32/Windows-icon.png)](https://fr.wikipedia.org/wiki/Microsoft_Windows)
```bash
Download python 2.7
Download Smtp Sender
Extract Smtp Sender into Desktop
Open CMD and type the following commands:
cd Desktop/Python-Sender-/
smtp.py
```
<h2>Version 1</h2>
<strong>Current version is 1</strong>
<strong>What's New </strong>
<p>• speed up<p>
<p>• Bug fixes<p>
  <h1>More Tools In My Facebook</h1>
https://www.facebook.com/007MrSpy
